package com.yupathbuilder.backend.repo;

import com.yupathbuilder.backend.entity.CourseEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CourseRepo extends JpaRepository<CourseEntity, Long> {

  CourseEntity findByCourseCode(String courseCode);

  List<CourseEntity> findTop20ByCourseCodeContainingIgnoreCaseOrTitleContainingIgnoreCase(
      String code,
      String title
  );
}