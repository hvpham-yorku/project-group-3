package com.yupathbuilder.backend.controller;

import com.yupathbuilder.backend.dto.CourseDto;
import com.yupathbuilder.backend.repo.CourseRepo;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/search")
public class SearchController {

  private final CourseRepo courseRepo;

  public SearchController(CourseRepo courseRepo) {
    this.courseRepo = courseRepo;
  }

  @GetMapping("/courses")
  public List<CourseDto> searchCourses(@RequestParam(name="q", defaultValue="") String q) {
    if (q == null || q.trim().isEmpty()) return List.of();

    var list = courseRepo.findTop20ByCourseCodeContainingIgnoreCaseOrTitleContainingIgnoreCase(q, q);
    return list.stream()
        .map(c -> new CourseDto(c.getCourseCode(), c.getTitle()))
        .toList();
  }
}