package com.yupathbuilder.backend.repo;

import com.yupathbuilder.backend.entity.SectionEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SectionRepo extends JpaRepository<SectionEntity, Long> {
  List<SectionEntity> findByCourse_CourseCodeAndTerm_Id(String courseCode, Long termId);
}